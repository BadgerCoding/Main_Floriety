package com.example.floriety

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
