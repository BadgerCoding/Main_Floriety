import 'dart:convert';

import 'package:http/http.dart' as http;

class ApiService {
  static const String _baseUrl =
      'http://10.32.30.193:5000'; //CHANGE NIIIIIIIIIIIIIIIIIIIIIIIIIIIII via terminal command: linux: ip addr show and window ipconfig. Replace with your backend IP on a real mobile device while testing over WiFi.

  static Future<Map<String, dynamic>> register(
    String email,
    String password,
  ) async {
    final uri = Uri.parse('$_baseUrl/api/register');
    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );
    final body = jsonDecode(response.body);
    if (response.statusCode != 201) {
      throw Exception(body['error'] ?? 'Registration failed');
    }
    return Map<String, dynamic>.from(body);
  }

  static Future<Map<String, dynamic>> login(
    String email,
    String password,
  ) async {
    final uri = Uri.parse('$_baseUrl/api/login');
    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );
    final body = jsonDecode(response.body);
    if (response.statusCode != 200) {
      throw Exception(body['error'] ?? 'Login failed');
    }
    return Map<String, dynamic>.from(body);
  }

  static Future<Map<String, dynamic>> getProfile(String token) async {
    final uri = Uri.parse('$_baseUrl/api/profile');
    final response = await http.get(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );
    final body = jsonDecode(response.body);
    if (response.statusCode != 200) {
      throw Exception(body['error'] ?? 'Failed to load profile');
    }
    return Map<String, dynamic>.from(body);
  }

  static Future<void> updateProfile(
    String token, {
    String? name,
    String? nickname,
    String? description,
    int? avatarIndex,
    bool? isDark,
  }) async {
    final uri = Uri.parse('$_baseUrl/api/profile');
    final payload = <String, dynamic>{};
    if (name != null) payload['name'] = name;
    if (nickname != null) payload['nickname'] = nickname;
    if (description != null) payload['description'] = description;
    if (avatarIndex != null) payload['avatar_index'] = avatarIndex;
    if (isDark != null) payload['is_dark'] = isDark;

    final response = await http.put(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode(payload),
    );
    final body = jsonDecode(response.body);
    if (response.statusCode != 200) {
      throw Exception(body['error'] ?? 'Failed to update profile');
    }
  }

  static Future<List<Map<String, dynamic>>> getHistory(String token) async {
    final uri = Uri.parse('$_baseUrl/api/history');
    final response = await http.get(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );
    final body = jsonDecode(response.body);
    if (response.statusCode != 200) {
      throw Exception(body['error'] ?? 'Failed to load history');
    }
    return List<Map<String, dynamic>>.from(body);
  }

  static Future<void> addHistory(
    String token,
    Map<String, String> flowerData,
  ) async {
    final uri = Uri.parse('$_baseUrl/api/history');
    final response = await http.post(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode(flowerData),
    );
    if (response.statusCode != 201) {
      final body = jsonDecode(response.body);
      throw Exception(body['error'] ?? 'Failed to save history');
    }
  }

  static Future<bool> toggleFavorite(String token, int historyId) async {
    final uri = Uri.parse('$_baseUrl/api/history/$historyId/favorite');
    final response = await http.put(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );
    final body = jsonDecode(response.body);
    if (response.statusCode != 200) {
      throw Exception(body['error'] ?? 'Failed to update favorite');
    }
    return body['is_favorite'] as bool? ?? false;
  }

  static Future<void> deleteHistory(String token, int historyId) async {
    final uri = Uri.parse('$_baseUrl/api/history/$historyId');
    final response = await http.delete(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );
    if (response.statusCode != 200) {
      final body = jsonDecode(response.body);
      throw Exception(body['error'] ?? 'Failed to delete history');
    }
  }

  static Future<void> submitFeedback(
    String token, {
    required String gmail,
    required String subject,
    required String message,
  }) async {
    final uri = Uri.parse('$_baseUrl/api/feedback');
    final response = await http.post(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'gmail': gmail,
        'subject': subject,
        'message': message,
      }),
    );
    if (response.statusCode != 201) {
      final body = jsonDecode(response.body);
      throw Exception(body['error'] ?? 'Failed to submit feedback');
    }
  }

  static Future<List<Map<String, dynamic>>> getChatHistory(String token) async {
    final uri = Uri.parse('$_baseUrl/api/chat/history');
    final response = await http.get(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );
    final body = jsonDecode(response.body);
    if (response.statusCode != 200) {
      throw Exception(body['error'] ?? 'Failed to load chat history');
    }
    return List<Map<String, dynamic>>.from(body);
  }

  static Future<Map<String, dynamic>> getChatConversation(
    String token,
    int historyId,
  ) async {
    final uri = Uri.parse('$_baseUrl/api/chat/history/$historyId');
    final response = await http.get(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );
    final body = jsonDecode(response.body);
    if (response.statusCode != 200) {
      throw Exception(body['error'] ?? 'Failed to load chat conversation');
    }
    return Map<String, dynamic>.from(body);
  }

  static Future<int> saveChatConversation(
    String token, {
    int? id,
    required String title,
    required List<Map<String, String>> messages,
  }) async {
    final uri = Uri.parse('$_baseUrl/api/chat/history');
    final payload = <String, dynamic>{'title': title, 'messages': messages};
    if (id != null) {
      payload['id'] = id;
    }
    final response = await http.post(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode(payload),
    );
    final body = jsonDecode(response.body);
    if (response.statusCode != 200) {
      throw Exception(body['error'] ?? 'Failed to save chat conversation');
    }
    return body['id'] as int? ?? 0;
  }
}
