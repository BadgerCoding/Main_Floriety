import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class GroqService {
  static const String _apiKey = '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';
  static const String _baseUrl = 'https://api.groq.com/openai/v1/chat/completions';

  static const String _textModel = 'llama-3.3-70b-versatile';
  static const String _visionModel = 'meta-llama/llama-4-scout-17b-16e-instruct';

  static Future<String> _postRequest(Map<String, dynamic> body) async {
    final response = await http.post(
      Uri.parse(_baseUrl),
      headers: {
        'Authorization': 'Bearer $_apiKey',
        'Content-Type': 'application/json',
      },
      body: jsonEncode(body),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['choices'][0]['message']['content'] as String;
    } else {
      throw Exception('Groq API error: ${response.statusCode} - ${response.body}');
    }
  }

  /// Scans a flower image (from file) and returns JSON with flower details.
  static Future<Map<String, String>> scanFlower(File imageFile) async {
    final bytes = await imageFile.readAsBytes();
    final base64Image = base64Encode(bytes);
    final extension = imageFile.path.split('.').last.toLowerCase();
    final mimeType = extension == 'png' ? 'image/png' : 'image/jpeg';

    final content = await _postRequest({
      'model': _visionModel,
      'messages': [
        {
          'role': 'user',
          'content': [
            {
              'type': 'image_url',
              'image_url': {
                'url': 'data:$mimeType;base64,$base64Image',
              },
            },
            {
              'type': 'text',
              'text': '''You are a professional botanist. Carefully examine this image.

IMPORTANT: Analyze ALL visible botanical features for maximum accuracy:
- Petal shape, color, count, and arrangement
- Leaf shape, margin (serrated/smooth), venation pattern, and attachment
- Stem structure and color
- Overall plant habit and growth form
- Any visible reproductive structures (stamens, pistils, sepals)

Based on this holistic analysis of both flower AND leaves/stems, identify the plant species with high confidence.

If the image does NOT contain a flower or plant at all, respond with isFlower set to "false".

Respond ONLY with a valid JSON object (no markdown, no extra text):
{
  "isFlower": "true",
  "name": "Most accurate common name of the flower",
  "scientific": "Scientific/Latin name (Genus species)",
  "family": "Botanical family name (e.g. Asteraceae, Rosaceae)",
  "variety_appearance": "Description of variety, cultivar, and visual appearance (color, size, petal form)",
  "origin": "Geographic origin or native region",
  "habitat": "Typical environment where this flower grows (e.g. tropical rainforest, alpine meadow, coastal dunes)",
  "allergen": "Allergen information (pollen type, severity)",
  "disease": "Disease or health condition observed on this specimen — if healthy say None detected",
  "care_list": "1. [care step]\\n2. [care step]\\n3. [care step] (list all crucial care steps specific to this flower — watering, sunlight, soil, pruning, fertilizer, repotting, humidity, etc. Include as many as needed)",
  "description": "2-3 sentence poetic yet informative description of this flower"
}

If this is NOT a flower/plant, respond with:
{
  "isFlower": "false",
  "name": "No Flower Detected",
  "scientific": "",
  "family": "",
  "variety_appearance": "",
  "origin": "",
  "habitat": "",
  "allergen": "",
  "disease": "",
  "care_list": "",
  "description": ""
}''',
            },
          ],
        },
      ],
      'max_tokens': 800,
    });

    try {
      // Strip any markdown code fences if present
      final cleaned = content
          .replaceAll('```json', '')
          .replaceAll('```', '')
          .trim();
      final Map<String, dynamic> parsed = jsonDecode(cleaned);
      return parsed.map((k, v) => MapEntry(k, v.toString()));
    } catch (_) {
      // Fallback if JSON parsing fails
      return {
        'isFlower': 'true',
        'name': 'Unknown Flower',
        'scientific': 'N/A',
        'family': 'N/A',
        'variety_appearance': 'N/A',
        'origin': 'N/A',
        'habitat': 'N/A',
        'allergen': 'N/A',
        'disease': 'N/A',
        'care_list': '1. Provide adequate water\n2. Ensure proper sunlight\n3. Use well-draining soil',
        'description': content,
      };
    }
  }

  /// Sends a chat message with conversation history and returns the AI reply.
  static Future<String> chat(List<Map<String, String>> messages) async {
    final systemMessage = {
      'role': 'system',
      'content':
          'You are Floriety AI, a friendly and knowledgeable botanical assistant. '
          'You specialize in flowers, plants, their care, history, and identification. '
          'Keep responses concise, helpful and engaging. Use occasional botanical terminology.',
    };

    final allMessages = [
      systemMessage,
      ...messages.map((m) => {'role': m['role']!, 'content': m['content']!}),
    ];

    return _postRequest({
      'model': _textModel,
      'messages': allMessages,
      'max_tokens': 512,
    });
  }

  /// Identifies a flower from a text description and returns flower data.
  static Future<Map<String, String>> identifyFlower(String description) async {
    final content = await _postRequest({
      'model': _textModel,
      'messages': [
        {
          'role': 'system',
          'content':
              'You are a botanical expert. When given a description of a flower, identify the best matching real flower and respond ONLY with a valid JSON object (no markdown, no explanation).',
        },
        {
          'role': 'user',
          'content':
              '''Based on this description: "$description"
Identify the best matching real flower and respond with ONLY a JSON object:
{
  "name": "Common name",
  "scientific": "Scientific name",
  "imagePrompt": "A beautiful high-quality photo of <flower name>, botanical illustration style",
  "description": "2-3 sentence description of this flower"
}''',
        },
      ],
      'max_tokens': 256,
    });

    try {
      final cleaned = content
          .replaceAll('```json', '')
          .replaceAll('```', '')
          .trim();
      final Map<String, dynamic> parsed = jsonDecode(cleaned);
      return parsed.map((k, v) => MapEntry(k, v.toString()));
    } catch (_) {
      return {
        'name': 'Mystery Flower',
        'scientific': 'Unknown species',
        'imagePrompt': 'beautiful flower botanical illustration',
        'description': content,
      };
    }
  }

  /// Generates a full care guide for a flower given its name and basic info.
  static Future<String> generateCareGuide(Map<String, String> flowerData) async {
    final name = flowerData['name'] ?? 'this flower';
    final scientific = flowerData['scientific'] ?? '';
    final origin = flowerData['origin'] ?? '';

    return _postRequest({
      'model': _textModel,
      'messages': [
        {
          'role': 'system',
          'content':
              'You are a professional botanist and horticulturist. Generate detailed, well-structured flower care guides.',
        },
        {
          'role': 'user',
          'content':
              '''Generate a comprehensive care guide for $name${scientific.isNotEmpty ? ' ($scientific)' : ''}${origin.isNotEmpty ? ', originally from $origin' : ''}.

Include these sections with emoji headers:
🌱 **Planting & Soil**
☀️ **Sunlight Requirements**
💧 **Watering Schedule**
🌡️ **Temperature & Humidity**
✂️ **Pruning & Maintenance**
🐛 **Common Pests & Diseases**
🌸 **Blooming Season**
💡 **Pro Tips**

Keep each section to 2-3 sentences. Be specific and practical.''',
        },
      ],
      'max_tokens': 800,
    });
  }
}
